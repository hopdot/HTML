from flask import Flask, render_template_string, jsonify

app = Flask(__name__)

html = """<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>HCoinX - Official Site</title>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <style>
        body { font-family: Arial, sans-serif; background-color: #121212; color: #f4f4f4; text-align: center; padding: 2em; }
        h1 { color: #00ffcc; }
        .section { margin: 2em 0; }
        a { color: #00ffcc; text-decoration: none; }
    </style>
</head>
<body>
    <h1>HCoinX (HCX)</h1>
    <p>Welcome to the official page for HCoinX, a decentralized currency for economic empowerment.</p>

    <div class='section'>
        <h2>Token Information</h2>
        <p><strong>Symbol:</strong> HCX</p>
        <p><strong>Owner:</strong> Howard Mosely Jr.</p>
        <p><strong>Contract Address:</strong> <code>0x9e82ba06E62209CAEEEE5E8bac5eb11265072a7D</code></p>
        <p><a href='https://etherscan.io/token/0x9e82ba06E62209CAEEEE5E8bac5eb11265072a7D' target='_blank'>View on Etherscan</a></p>
    </div>

    <div class='section'>
        <h2>Get Listed</h2>
        <p><a href='https://docs.google.com/forms/d/e/1FAIpQLSe2MogkhaOubp-n6OhA5RMgs-qWQKgTfCl5zB4VJavLD-l_CQ/viewform' target='_blank'>Submit to CoinGecko</a></p>
        <p><a href='https://coinmarketcap.com/request/' target='_blank'>Submit to CoinMarketCap</a></p>
    </div>

    <div class='section'>
        <h2>Contact</h2>
        <p>Email: <a href='mailto:moselyjrhcoinx@gmail.com'>moselyjrhcoinx@gmail.com</a></p>
    </div>
</body>
</html>"""

@app.route("/")
def home():
    return render_template_string(html)

@app.route("/api/token")
def token_info():
    return jsonify({
        "name": "HCoinX",
        "symbol": "HCX",
        "owner": "Howard Mosely Jr.",
        "contract_address": "0x9e82ba06E62209CAEEEE5E8bac5eb11265072a7D",
        "decimals": 18
    })

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)