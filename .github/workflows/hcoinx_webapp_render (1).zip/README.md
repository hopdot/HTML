# HCoinX Web App

This is the official Flask-based web app for the HCoinX (HCX) cryptocurrency.

## Features
- Homepage with token and contract information
- API endpoint `/api/token` returning metadata in JSON

## Run Locally

```bash
pip install -r requirements.txt
python app.py
```

Visit: `http://localhost:5000`

## Deployment on Render

1. Upload this project to GitHub:

```bash
git init
git remote add origin https://github.com/YOUR_USERNAME/hcoinx-webapp.git
git add .
git commit -m "Initial commit - HCoinX WebApp"
git push -u origin main
```

2. Go to [Render](https://dashboard.render.com/)
3. Create a **New Web Service**
4. Connect your GitHub repo
5. Render will detect `requirements.txt`
6. Use the Free Plan
7. App will deploy and give you a live URL

## Owner

- Howard Mosely Jr.
- Contact: moselyjrhcoinx@gmail.com